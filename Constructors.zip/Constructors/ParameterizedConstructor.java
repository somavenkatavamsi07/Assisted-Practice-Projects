package Constructors;

public class ParameterizedConstructor {
	
	int id;
	String name;

	ParameterizedConstructor(int i,String n)
	{
	id=i;
	name=n;
	}

	public void display() {
	System.out.println(id+" "+name);
	}

public static void main(String[] args) {

	ParameterizedConstructor std1=new ParameterizedConstructor(1,"Vamsi");
	ParameterizedConstructor std2=new ParameterizedConstructor(2,"Subbaiah");
	std1.display();
	std2.display();

}
}
