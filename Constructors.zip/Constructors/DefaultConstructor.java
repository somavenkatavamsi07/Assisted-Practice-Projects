package Constructors;

public class DefaultConstructor {
	
	int avg;
	String id;

void display() {
	System.out.println(avg+" "+id);
	}

public static void main(String[] args) {

	DefaultConstructor emp1=new DefaultConstructor();
	DefaultConstructor emp2=new DefaultConstructor();

	emp1.display();
	emp2.display();

}
}
