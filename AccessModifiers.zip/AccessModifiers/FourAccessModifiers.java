package AccessModifiers;

public class FourAccessModifiers {
	void display1() 
    { 
        System.out.println("Default Modifier"); 
    } 
	public void display2() 
    { 
        System.out.println("Public Modifier"); 
    } 
	private void display3() 
    { 
        System.out.println("private Modifier"); 
    } 
	protected void display4() 
    { 
        System.out.println("protected Modifier"); 
    } 


	public static void main(String[] args) {
		FourAccessModifiers obj = new FourAccessModifiers(); 		  
        obj.display1(); 
        obj.display2();
        obj.display3();
        obj.display4();
}
}
