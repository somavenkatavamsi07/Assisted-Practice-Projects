package AccessModifiers;

public class PrivateAccess {
	
	 
	   private void display() 
	    { 
	        System.out.println("You are using private access specifier"); 
	    } 
	
	
		public static void main(String[] args) {
			//private
			System.out.println("Private Access Specifier");
			PrivateAccess  obj = new PrivateAccess(); 
	        //trying to access private method of another class 
	        obj.display();
		}
}

