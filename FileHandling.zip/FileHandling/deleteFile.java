package FileHandling;
import java.io.File;

public class deleteFile {
	public static void main(String[] args) {
		File myFile = new File("anirudh.txt");
		if(myFile.delete()) {
			System.out.println("File deleted  Successfully...");
		}
		else {
			System.out.println("File deletion error...");
		}
	}

}