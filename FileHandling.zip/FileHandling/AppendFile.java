package FileHandling;
import java.io.FileWriter;
import java.io.IOException;

public class AppendFile {

	public static void main(String[] args) {
		String data ="I am from Kadapa";
		try {
			FileWriter output = new FileWriter("vamsi.txt",true);
			output.write(data);
			System.out.println("data appended successfully");
			output.close();
		} catch (IOException e) {
			System.out.println("file append error ...");
		}

	}

}
