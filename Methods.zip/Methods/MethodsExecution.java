package Methods;

public class MethodsExecution {
	
	public int sum(int a,int b) {
		int c=a+b;
		return c;
	}

	public static void main(String[] args) {

		MethodsExecution ob=new MethodsExecution();
		int result = ob.sum(100,300);
		System.out.println("Sum is :"+result);

}
}
