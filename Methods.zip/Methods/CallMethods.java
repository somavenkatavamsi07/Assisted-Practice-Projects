package Methods;

public class CallMethods {
	int a=150;

	int operation(int a) {
		a =a*10/100;
		return(a);
	}

	public static void main(String args[]) {
		CallMethods ob = new CallMethods();
		System.out.println("Before operation value of data is "+ob.a);
		int y=ob.operation(1500);
		System.out.println("After operation value of data is "+y);
	

}
}
