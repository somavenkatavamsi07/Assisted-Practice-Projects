package Methods;

public class MethodsOverloading {
	
	public void area(int b,int h)
    {
         System.out.println("Area of Triangle : "+(0.5*b*h));
    }
    public void area1(int r) 
    {
         System.out.println("Area of Circle : "+(3.14*r*r));
    }

    public static void main(String args[])
   {

        MethodsOverloading ob=new MethodsOverloading();
        ob.area(2,3);
        ob.area1(4);  

}
}
